#import <Flutter/Flutter.h>

@interface LpprinterPlugin : NSObject<FlutterPlugin>
@end
